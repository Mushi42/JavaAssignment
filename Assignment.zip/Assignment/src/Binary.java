/**
 *  Date : Wednesday,28 November 2018  :: 1:04am
 *
 * @author Anonymous
 */
//You are supposed to add your comments

import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import javax.swing.JOptionPane;

public class Binary implements Serializable {

    public static void main(String[] args) throws IOException {    
        String Ct_Wo = "", temp1 = "The reason that we should all be subject unto the higher powers, "
                + "is due to two things: “there is no power but of God,” and “the powers that be are ordained of God.";
        int NW = 0, NS = 0;
        String LaCh = "";
        for (char c : temp1.toCharArray()) {
            int charcl = c;
            if (charcl == 32)
            {
                NW++;
            }
            if ((LaCh.equals("?") || LaCh.equals("!") || LaCh.equals(".")) && (charcl == 32)) 
            {
                NW--;
            } else if ((charcl == 46) || (charcl == 33) || (charcl == 63))
            {
                NW++;
                NS++;
            }     
            LaCh = String.valueOf(c);
        }
        
        int LastM = 0;
        String WordMax = "", LastChar = "";
        int anewl = 10;
        char anew = (char) anewl;
        
        String temp = temp1.substring(1);
        String newl = String.valueOf(anew);
        
        while (temp.length() > 0) {
            String d = temp.substring(0, 1);
            temp = temp.substring(1);
            
            if (d.equals(newl)) {

            } else {
                if (d.equals(" ") || d.equals(".") || d.equals("?") || d.equals("!")) {
                    if (WordMax.length() > LastM) {
                        if ((LastChar.equals(" ") && d.equals(".")) || (LastChar.equals(" ") && d.equals("?") || (LastChar.equals(" ") && d.equals("!")))) {
                            WordMax = WordMax.substring(1);
                                         
                        } else if ((LastChar.equals(".") && d.equals(" ")) || (LastChar.equals("?") && d.equals(" ") || (LastChar.equals("!") && d.equals(" ")))) {
                            WordMax = WordMax.substring(1);
                        } else {
                            LastM = WordMax.length();
                        }
                    }
                    WordMax = "";
                } else {
                    WordMax = WordMax + d;
                    LastChar = d;
                }
            }
        }
        LastM++;
        int[] Rj = new int[LastM];
        int[] Tj = new int[LastM];
        int j1 = 0, CS = 0, sum = 0;
        for (j1 = 1; j1 < LastM; j1++) {
            sum = 0;
            int roundedup = 0;
            for (char c : temp1.toCharArray()) {
                String d2 = String.valueOf(c);
                if (d2.equals(".") || d2.equals("!") || d2.equals("?") || d2.equals(newl)) {
                    CS++;
                }
                int nc = c;
                if (nc != 32) {
                    Ct_Wo = Ct_Wo + c;
                } else {
                    if ((nc == 32) || (nc == 10) || (nc == 33) || (nc == 63)) {
                        if (j1 == Ct_Wo.length()) {
                            sum = sum + (j1 * CS);
                        }
                        Ct_Wo = "";
                    }
                }
            }
            Ct_Wo = "";
            Rj[j1] = sum;
    
            double S = (double) (Rj[j1]) / (NS + 1);
            roundedup = (int) Math.round(S);
            Tj[j1] = roundedup;
        }
        int ZigmaR = 0, ZigmaT = 0;
        JOptionPane.showMessageDialog(null, "Click to Load the Extracted Values");
        for (int i1 = 1; i1 < LastM; i1++) {
           
            System.out.println("Rj" + i1 + ": " + Rj[i1] + "  Tj: " + Tj[i1]);
            ZigmaR = ZigmaR + Rj[i1];
            ZigmaT = ZigmaT + Tj[i1];
        }
        
        JOptionPane.showMessageDialog(null," Zigma Rj: " + ZigmaR + " \n Zigma Tj: " + ZigmaT + "\n Entropy Factor: " + (ZigmaR - ZigmaT) + "\n NW: " + String.valueOf(NW) + "\n LastM: " + LastM);
        
// File Handling : All the Values GOT are stored in a file which is stored in directory of project :)
       
         try(FileWriter out = new FileWriter(String.valueOf(NS))) {
             out.append(String.valueOf(ZigmaR)+" , ");
             out.append(String.valueOf(ZigmaT)+" , ");
             out.append(String.valueOf(ZigmaR-ZigmaT)+" , ");
             out.append(String.valueOf(NW)+" , ");
             out.append(String.valueOf(LastM)+" , ");
         
         }catch(IOException e){
             System.out.println(e.fillInStackTrace());
         }
  }
}
